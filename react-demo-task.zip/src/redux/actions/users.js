import { createAction } from '@reduxjs/toolkit';

const setUsers = createAction('setUsers');

export { setUsers };
