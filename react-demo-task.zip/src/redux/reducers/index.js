import auth from './authReducers';
import users from './usersReducers';

export default { auth, users };
